﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Test_Task_Api.Models;


namespace Test_Task_Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class TaskTestsController : ControllerBase
    {
        private readonly AppDbContext _context;

        public TaskTestsController(AppDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<TaskTest>>> GetAll()
        {
            return await _context.TaskTests.ToListAsync();
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<TaskTest>> GetById(long id)
        {
            var task = await _context.TaskTests.FindAsync(id);
            if (task == null) return NotFound();

            return task;
        }

        [HttpPost]
        public async Task<ActionResult<TaskTest>> Create(TaskTest task)
        {
            _context.TaskTests.Add(task);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(GetById), new { id = task.Id_Task }, task);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Update(long id, TaskTest task)
        {
            if (id != task.Id_Task)
                return BadRequest();

            _context.Entry(task).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!_context.TaskTests.Any(e => e.Id_Task == id))
                    return NotFound();

                throw;
            }

            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(long id)
        {
            var task = await _context.TaskTests.FindAsync(id);
            if (task == null)
                return NotFound();

            _context.TaskTests.Remove(task);
            await _context.SaveChangesAsync();
            return NoContent();
        }
    }
}
