﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Test_Task_Api.Models;

public partial class TaskTest
{
    [Key]
    [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
    public long Id_Task { get; set; }

    public DateTime? EntryDate { get; set; }

    public string? Description { get; set; }

    public string? Priority { get; set; }

    public string? Owner { get; set; }

    public string? Status { get; set; }

    public DateTime? StartDate { get; set; }

    public DateTime? EndDate { get; set; }
}
